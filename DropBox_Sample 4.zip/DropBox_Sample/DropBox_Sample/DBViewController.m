//
//  DBViewController.m
//  DropBox_Sample
//
//  Created by basanth alluri on 12/24/13.
//  Copyright (c) 2013 StellentSoft. All rights reserved.
//

#import "DBViewController.h"
#import "DBObject.h"
#import "DBDetailViewController.h"

@interface DBViewController ()

@end

@implementation DBViewController

@synthesize accountManager;
@synthesize account;
@synthesize store;
@synthesize tasks;
@synthesize objectsArray;

@synthesize taskNameTextField;
@synthesize taskCompleteTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (IBAction)didPressLink
{
    [[DBAccountManager sharedManager] linkFromController:self];
    /*
    if (![[DBAccountManager sharedManager] linkedAccount].isLinked)
    {
        [[DBAccountManager sharedManager] linkFromController:self];
    }
    
    else
    {
        UIAlertView *tempale=[[UIAlertView alloc]initWithTitle:@"Dropbox" message:@"already linked" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [tempale show];
    }
     */
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    tasks=[[NSMutableArray alloc]init];
    objectsArray=[[NSMutableArray alloc]init];

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
   
}

- (IBAction)submitButtonAction
{
    
    if (taskCompleteTextField.text.length!=0 && taskNameTextField.text.length!=0)
    {
        __weak DBViewController *slf = self;
        [self.accountManager addObserver:self block:^(DBAccount *account)
         {
             [slf setupTasks];
             //  [slf deleteRecordsFromDropBox];
             //[slf updateRecordsFromDropBox];
             
         }];
        
        [self setupTasks];
        //[self getDataFromDropBox];
        //[self updateRecordsFromDropBox];
        //[self deleteRecordsFromDropBox];
    }
    else
    {
        
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"DropBox" message:@"Enter all fields" delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
        [alertView show];
        
    }
   
    
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    return [textField resignFirstResponder];
}

- (IBAction)detailViewButtonAction
{
    DBDetailViewController *viewCtlr=[[DBDetailViewController alloc]initWithNibName:@"DBDetailViewController" bundle:nil];
   [self.navigationController pushViewController:viewCtlr animated:YES];
 
}

#pragma mark - private methods

- (DBAccount *)account {
    return [DBAccountManager sharedManager].linkedAccount;
}

- (DBAccountManager *)accountManager {
    return [DBAccountManager sharedManager];
}

- (DBDatastore *)store
{
    if (!store)
    {
        store = [DBDatastore openDefaultStoreForAccount:self.account error:nil];
    }
    return store;
}

#pragma mark Save Details in form of tables in DropBox
- (void)setupTasks
{
    
    if (self.account)
    {
        
           DBTable *tasksTbl = [self.store getTable:@"sampleTable"];
        
            DBRecord *task = [tasksTbl insert:@{ @"taskname": taskNameTextField.text, @"completed": taskCompleteTextField.text, @"created":[NSDate date] } ];
            [tasks addObject:task];
            
            __weak DBViewController *slf = self;
            [self.store addObserver:self block:^ {
                if (slf.store.status & (DBDatastoreIncoming | DBDatastoreOutgoing)) {
                    [slf syncTasks];
                }
            }];
            //tasks = [NSMutableArray arrayWithArray:[[self.store getTable:@"sampleTable"] query:nil error:nil]];
            [self.store sync:nil];

        
        
    } else {
        store = nil;
        tasks = nil;
    }
    //[self.tableView reloadData];
    [self syncTasks];
}

- (void)syncTasks
{
    NSLog(@"Self Account is %@",self.account);
    if (self.account)
    {
        NSDictionary *changed = [self.store sync:nil];
        NSLog(@"Data is Synced");
      //  [self update:changed];
        
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"DropBox" message:@"Data is saved successfully" delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
        [alertView show];
    }
    else
    {
        
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"DropBox" message:@"Data is not saved " delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
        [alertView show];
    }
    
    
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
